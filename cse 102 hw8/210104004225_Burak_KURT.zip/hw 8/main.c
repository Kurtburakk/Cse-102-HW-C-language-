#include <stdio.h>
#include <stdlib.h>
#include "util.h"

int main() {

    int seqlen;
    int xs,temp;
    int looplen;

    printf("Please enter the sequence length: ");
    scanf("%d",&seqlen);
    printf("Please enter the first element: ");
    scanf("%d",&xs);
    looplen=seqlen/2;
    int *loop =(int*)malloc((seqlen/2)* sizeof(int)); /*we allocated memory*/
    
    check_loop_iterative(generate_sequence,xs,seqlen,loop,&looplen);
    if(looplen>1){ /*this part print the loop if looplen not equal to zero */
     printf("Loop : {");
    
    for(int j=0;j<looplen;j++){
     if(j==looplen-1){
     printf("%d",*(loop+j));
     }
     else{
     printf("%d,",*(loop+j));
     }    
    }
     printf("}\n");
    }
    int *h =(int*)malloc(9 * sizeof(int)); /*we allocate up to bytes of memory*/

    int digit=1;
    hist_of_firstdigits(generate_sequence,xs,seqlen,h,digit);
    
    printf("\nHistogram of the sequence : {");
    for(int k=0;k<9;k++){/*this part print histogram of sequence.*/
     if(k==8){
     printf("%d",*(h+k));
     }
     else{
     printf("%d,",*(h+k));
     }    
     }
     printf("}\n");
    printf("\n");
    return(0);
}
