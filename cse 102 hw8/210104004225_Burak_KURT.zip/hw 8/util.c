#include <stdio.h>
#include <stdlib.h>
#include "util.h"

void generate_sequence (int xs, int currentlen, int seqlen, int *seq){
     
     if(currentlen<seqlen){
     if(xs%2==0){
      *seq=xs;
      generate_sequence (xs/2,currentlen+1,seqlen,seq+1);/*call the other element of the sequence*/
      }
      else{
      *seq=xs;
      generate_sequence ((xs*3)+1,currentlen+1,seqlen,seq+1);/*call the other element of the sequence*/    
      }
     }
}
int has_loop(int *arr, int n, int looplen, int *ls, int *le){
     int a=0;
     int i=0;
     int check_loop=0;
     int find_loop=0;
     printf("Checking if there is a loop of length %d...\n",looplen);

     while((a+looplen+looplen-1)<n){ /*this part continue the last of term sequence*/
     check_loop=0;
     if(find_loop==0){
      for(i=0;i<looplen;i++){
       if(*(arr+i+a)==*(arr+n-looplen+i)){
         check_loop++;
       }
      }
      if(check_loop==looplen){ /*if find  a loop this part hold to first and last term of loop.*/
          find_loop=1;
          *ls=a;
          *le=a+looplen;
      }
    }
    a++;/*this integer provide the checking each of elements.*/
     }
     if(find_loop==1){
          return 1;
     }
     else {
          return 0;}
}
void check_loop_iterative(void (*f)(), int xs, int seqlen, int *loop, int *looplen){
     
    static int currentlen=0;
    int *seq=(int*)malloc(seqlen* sizeof(int));
    int *arr=(int*)malloc(seqlen* sizeof(int)); 
    int le;
    int ls;
    int found_loop=0;
    int result=0;
       
     f(xs,currentlen,seqlen,seq);

     for(int i=0;i<seqlen;i++){ /*this part copy the seq  into the arr array*/
           *(arr+i)=*(seq+i);
     
     if(currentlen==0){
      for(int i=0;i<seqlen;i++){ /*this part print the sequence only once*/
           printf("%d ",*(seq+i));
      }
      printf("\n");
      }
      currentlen++;/*this integer provide print only once*/
     }
     free(seq);
     free(arr);
     if(*looplen>1 && found_loop==0){  /*It will continue until the looplen equal to 1 or found_loop equal to 1.*/
     result=has_loop(arr,seqlen,*looplen,&ls,&le);
     if(result==1){
     found_loop=1;
     printf("\n\nLoop detected with a length of %d.\n",*looplen);
     printf("The indexes of the loop's first occurance: %d (first digit), %d (last digit)\n",ls,le);

     int a=ls;
     int b=0;
     while(a<le){ /*this part takes the loop into the *(loop) array*/
     *(loop+b)=*(seq+a);
     a++;
     b++;
     }
      }
     else {
          *looplen-=1;
          check_loop_iterative(f,xs,seqlen,loop,looplen);/*if not find a loop ,decrease looplen and again call the function */
     }    
     }
     else if(*looplen==1 && found_loop==0){
          printf("No loop found.\n");
          *looplen=0; /*if not find a loop ,looplen equal to zero.*/
     }
}
void hist_of_firstdigits(void (*f)(), int xs, int seqlen, int *h, int digit){
     int currentlen=0;
     int *seq=(int*)malloc(seqlen* sizeof(int));
     f(xs,currentlen,seqlen,seq);
     int temp;
     int count=0;

     if(digit<9){/*It will continue until the number 9.*/
     for(int i=0;i<seqlen;i++){
         
         temp=*(seq+i);/*this temp integer hold to each term of sequence */
         while(temp>= 10) /*this part find first digit*/
         {
         temp = temp / 10;
         }
         if(temp==digit){
              count++;
         }
     }
     *(h+digit-1)=count;/* this part put the  count number in digit array */
    hist_of_firstdigits(generate_sequence,xs,seqlen,h,digit+1);/*increase digit and again call the this function.*/
     }
}



