#include <stdio.h>
#include "util.h"

int find_divisible(int x, int y, int z){

    /*The check_divisible to be returned will not change if there is no divisible number in the loop,it will go as an error.*/
    int check_divisible=-1;
    int check_first=1; /* The check_first will allow us to get the first divisible value */
    int i;
  
    for(i=x+1;i<y;i++){
    
    /*When the first divisible value comes, check_first will change to zero and it will allow us not to take other values */
    if(i%z==0 && check_first==1){ 
    check_divisible=i;
    check_first=0;      
      }
     }   
    return check_divisible; /* Returns the first divisible value or -1 */
   }

int find_nth_divisible(int n, int f_I, int z){

    int n_I; 
 
    n_I=n*z+f_I; /*n steps find the next value.*/
    
    return n_I;
   }

int validate_identity_number(char identity_number[]){

    int check_ID=0;/*Id number will evaluate to 5 check digits,if all are true it will get value 5.*/
    int check_digit=0;
    int odd=0,even=0,sum=0,i;
    for(i=0;identity_number[i]!='\0';i++){ 
    /* This loop will go up to the last character. The value (i) will be equal to the number of elements of the array.*/
    
    if(48<=identity_number[i]<=57){ 
    check_digit++;
    /*Checking if each character is equal to digit values in ascii table */
     }
    } 
    if(i==11 && check_digit==11){ /*If ID number is 11 characters and all digits, check_ID will increase by 2 */
    check_ID++;
    check_ID++; 
    }
    /*Since our numbers are kept as characters in arrays, we subtract the value from 0 in the ascii table (48) to access their real values. */
    
    if((identity_number[0]-48)!=0){ /*check_ID will increment by one,if first character is not equal to zero.*/
    check_ID++;
    }
    
    for(i=0;i<9;i++){
    
    if(i%2==0){ /* Since the first element in the arrays is the 0 th term, there will be one shift.  */
    odd=odd+(identity_number[i]-48);/* 1,3,5,7,9 terms. */
     }
    else{
    even=even+(identity_number[i]-48);/* 2,4,6,8 terms. */
     }
    }
    if((odd*7-even)%10==(identity_number[9]-48)){ /*We are doing the 4th check, if it is true, the check id increases by 1.*/
    check_ID++;
    }
    
    for(i=0;i<10;i++){
    sum=sum+(identity_number[i]-48);/* Add the first 10 terms.*/
    }
    
    if(sum%10==(identity_number[10]-48)){/*We are doing the 5th check, if it is true, the check id increases by 1.*/
    check_ID++;
    }
  
    if (check_ID==5){ /* If all the steps are correct, we get the check_id 5 and return 1.*/
    return 1;
    }
    else {
    return 0;
    }
   }
    int create_customer(char identity_number [ ], int password){
    
    FILE *file;
    file=fopen("customeraccount.txt","w");
    fprintf(file,"%s,%d",identity_number,password); /* Saving ID number and password to file. */
    fclose(file);
    return 1; /* This function returns 1,if it worked.*/
   }
    int check_login(char identity_number [ ], int password){
    
    char check_ID[11],c;
    int check_log=0,check_password=0;;
    int check_pass,i;
    
    FILE *file;
    file=fopen("customeraccount.txt","r");/*The created file is opened and read permission is granted.*/
    fscanf(file,"%11[^,]%c%d",check_ID,&c,&check_pass);
    /* This fscanf function, first 11 characters will be taken, the comma in between will be kept in the character named c, and the password part will be taken as an integer. */    
    fclose(file);
    for(i=0;i<11;i++){
    if(identity_number[i]==check_ID[i]){ 
    /*Comparing the entered ID number with the ID number.Each character will be checked one by one, if all are correct, check_log will take the value 11. */
    check_log++;
     }
    }
    if(password==check_pass){
    /*Comparing the entered password with the password in the file is true, the check_password increases by 1. */
    check_password++;
    }
    if(check_log==11 && check_password==1){ /*If the two check steps are true, value 1 will be returned.*/
    return 1;
    }
    else {
    return 0;
    }
   }
   int withdrawable_amount(float cash_amount){
   
   int cash=0; /*If there is no amount of money that can be withdrawn, it will return as an error code of 0.*/
   cash=(int)(cash_amount); /* Discards the fractional part of the number.*/
   
   cash=cash-(cash%10);
   /* Converts the entered amount into a form that can be paid with 10 20 50 lira banknotes.The part in the ones digit is found and subtracted. */
   
   return cash; /* The amount that can be withdrawn is returned. */
   }

