#include <stdio.h>
#include "util.h"

int main() {
						/* PART 1 */ 
    int x,y,z,n,f_I,n_I;
                                           
    printf("Enter the first integer:");
    scanf("%d",&x);
    printf("Enter the second integer:"); 
    scanf("%d",&y);
    printf("Enter the divisor:");
    scanf("%d",&z);
    
    /*This function checks if there are any numbers that can be divided between the boundaries. */ 
    f_I=find_divisible(x,y,z);
   
    if(f_I==-1){  /*Returns -1 if there is no divisible number */
    printf("There is not any integer between %d and %d can be divided by %d.",x,y,z);
    printf("\n");
     }
       
    else {    
    printf("The first integer between %d and %d divided by %d is %d.",x,y,z,f_I);    
    printf("\n");
    printf("Enter the number how many next: ");
    scanf("%d",&n);
    
    if(n*z+f_I<y){ /*If the value we want after n steps does not exceed the limit, it send its to the function. */
    
    n_I=find_nth_divisible(n,f_I,z);/*This function finds the value after n steps.*/
    
    printf("The %dth integer between %d and %d divided by %d is %d.",n+1,x,y,z,n_I);
    printf("\n");
      }
    
    else { /*If the value we want after n steps exceeds the limit, it says there is no number */
    printf("No possible to find %dth divisible between %d and %d divided by %d.",n+1,x,y,z);
    printf("\n");
      }  
    } 
                                          /* PART 2 */ 
                   
    char identity_number[20];
    int check_ID,i; 
    int password;
    int check_account=0;  /*If the create_costumer function works it will return a value and this value will change, if it fails to return the value will remain 0 and give an error */
    
    printf("Please enter your identity number : ");
    scanf("%s",identity_number);
    
    check_ID=validate_identity_number(identity_number); /*This function checking ID number.*/
    
    if(check_ID==1){
     printf("You entered a valid ID number.");
     printf("\n");
     do{
     printf("Please set your four digit password: ");
     scanf("%d",&password);
     } while((1000>password) || (password>9999));/*This loop ensures that the password is four digits.*/
    
     printf("Your password has been created."); 
     printf("\n");
    
     check_account=create_customer(identity_number,password);/*This function save ID number and password.*/ 
     if(check_account==1){
     printf("Your account has been created.");
     printf("\n");
      }
     else{
     printf("Your account could not be created."); 
     /*If the check account value is not 1, it will mean that the function is not working and it will give this message. */
     printf("\n"); 
      }
      
    }
    else { /*The ID number you entered does not belong to a real person, the function returned 0.*/
    printf("You entered an invalid ID number.");
    printf("\n");
    }
                                           /* PART 3 */ 
    float cash_amount;
    int account_login;
    int withdrawable_cash;
    
    if(check_account==1){ /* If the account has been created, this step will be passed.*/
    printf("You are logging into your account");
    printf("\n"); 
    printf("Please enter your identity number : ");
    scanf("%s",identity_number);
    printf("Enter your password: ");
    scanf("%d",&password);
    }
    
    account_login=check_login(identity_number,password); /* This function checks the correctness of ID number and password.*/
                                           
    if(account_login==1){ /* If the user has accessed own account,user proceeds to this step.*/
     printf("“Login Successful”");
     printf("\n");
     do{
     printf("Enter your withdraw amount: ");
     scanf("%f",&cash_amount);
     } while(cash_amount<9); /*Values less than 10 cannot be entered.*/
     
     withdrawable_cash=withdrawable_amount(cash_amount); /* This function returns the amount of money that can be withdrawn.*/
     
     if(withdrawable_cash!=0){
     printf("Withdrawable amount is: %d",withdrawable_cash);
     printf("\n");
      }
     else{
     printf("This amount cannot be withdrawn.");
       }
      }               
    else { 
    /*If the value of 1 is not returned from the check login function, the person entered the wrong ID number or password.*/
     printf("Invalid identity number or password. ");
     printf("\n");
      } 
     
    return(0);
}
