#include <stdio.h>
#include <math.h>
#define PI 3.14

enum shapes {Triangle=1, Quadrilateral, Circle, Pyramid, Cylinder};
enum calculators {Area=1, Perimeter, Volume};

int select_shape ();         
int select_calc ();
int calculate (int (*st_shp)(), int (*st_cal)());
int calc_triangle(int choice);
int calc_quadrilateral(int choice);
int calc_circle(int choice);
int calc_pyramid(int choice);
int calc_cylinder(int choice);
int check_num();  /*This function check enter value is number or not.*/

int main(){

    calculate(select_shape, select_calc);

    return 0;
}
int select_shape (){

    int shape;
    
    do{
        printf("Welcome to the geometric calculator! \n ");
        printf("Select a shape to calculate:\n ");
        printf("------------------------- \n ");
        printf("1. Triangle \n ");
        printf("2. Quadrilateral \n ");
        printf("3. Circle \n ");
        printf("4. Pyramid \n ");
        printf("5. Cylinder \n ");
        printf("0. Exit \n ");
        printf("------------------------- \n ");

        printf("Input:");
        shape=check_num();
        
        if((shape != 0)&&(shape != 1)&&(shape != 2)&&(shape != 3)&&(shape != 4)&&(shape != 5)){

        printf("!Error Pleas enter valid number \n"); /*this part give error message*/
         }          
        }while ((shape != 0)&&(shape != 1)&&(shape != 2)&&(shape != 3)&&(shape != 4)&&(shape != 5));
        /*this loop allows to get specific numbers to shape integer*/
        
        switch(shape){ 
        
        case Triangle: /*Returns values based on enumerated numbers*/
        return Triangle;
        break;   
        
        case Quadrilateral:
        return Quadrilateral;
        break;
        
        case Circle:
        return Circle;
        break;
        
        case Pyramid:
        return Pyramid;
        break;
        
        case Cylinder:
        return Cylinder;
        break;
        
        default:
        return 0;
        }
}

int select_calc (){

    int calculator;
    
    do{

        printf("Select to calculator:\n ");
        printf("------------------------- \n ");
        printf("1. Area \n ");
        printf("2. Perimeter \n ");
        printf("3. Volume \n ");
        printf("0. Exit \n ");
        printf("------------------------- \n ");
        
        printf("Input:");
        calculator=check_num();
        
        if((calculator != 0)&&(calculator != 1)&&(calculator != 2)&&(calculator != 3)&&(calculator != 0)){
        printf("!Error Pleas enter valid number \n\n"); /*gives an error message*/
         }

    }while((calculator != 0)&&(calculator != 1)&&(calculator != 2)&&(calculator != 3)&&(calculator != 0));
    /*this loop allows to get specific numbers to calculator integer*/
    
    switch(calculator){ 
        
        case Area:    /*Returns values based on enumerated numbers*/
        return Area;
        break;   
        
        case Perimeter:
        return Perimeter;
        break;
        
        case Volume:
        return Volume;
        break;
        
        default:
        return 0;
        }
}
int calculate (int (*st_shp)(), int (*st_cal)()){

    int choice1,choice2;
    
    do{   
    choice1=st_shp();
    if(choice1!=0){ /*if user enter 0 shape function,this condition not allow to call calculator function. */
    choice2=st_cal(); 
    }
    if((choice1!=0)&&(choice2!=0)){/*if user enter 0,this condition not allow to enter other function.*/
    switch(choice1){
    
     case Triangle:  
     calc_triangle(choice2); /*whatever the shape is wanted to calculate is sent to the function*/          
     break;   
        
     case Quadrilateral:
     calc_quadrilateral(choice2);
     break;
        
     case Circle:
     calc_circle(choice2);
     break;
        
     case Pyramid:
     calc_pyramid(choice2);
     break;
        
     case Cylinder:
     calc_cylinder(choice2);
     break;
      }
     }
    }while((choice1!=0)&&(choice2!=0));/*if user enter exıt(0),exit this loop. */
}

int calc_triangle(int choice){

    float a,b,c;
    float check_triangle,s,area_triangle;
        
        if(choice!=3){ /*if user select volume ,this condition not allow this part.*/
        do{        
        printf("Please enter three sides of Triangle :");
        a=check_num();
        if(a>0){ /*if the entered value is invalid,this condition is not allow get other value.*/
        b=check_num();
        if(b>0){ 
        c=check_num();
         }
        }
        if((a<=0)||(b<=0)||(c<=0)){
        printf("!Error Pleas enter valid number. \n"); /*gives en error mesagge*/
        }
        
        if((a>0)&&(b>0)&&(c>0)){ /*If each side of the triangle is positive, it goes into this loop.*/
        
        check_triangle=0;
        if(a+b>c){ /*this condition check each side */
        check_triangle++;}
        if(a+c>b){
        check_triangle++;}
        if(b+c>a){
        check_triangle++;}
        
        if(check_triangle!=3){ /*if check_triangle=3,entered triangle is valid.*/
        printf("!Error Pleas enter valid triangle. \n");
         }
        }      
        
        }while((a<=0)||(b<=0)||(c<=0)||(check_triangle!=3));/*if each conditions are true,exit loop.*/
        
        }        
         switch(choice){ /*whatever the calculator is wanted to calculate is sent to the function*/
          
         case Area:
         
         s=(a+b+c)/2.0;
        
         area_triangle=s*(s-a)*(s-b)*(s-c);
         
         printf("Area of TRIANGLE : %f",sqrt(area_triangle));        
         break;
        
         case Perimeter:
         
         printf("Perimeter of TRIANGLE : %f",(a+b+c));        
         break;

         case Volume:
        
         printf("!ERROR You cannot calculate the volume of triangle.Please try again.");        
         break;
         }
         printf("\n");
         printf("\n");
         return 0;
}

int calc_quadrilateral(int choice){

    float a,b,c,d;
    float s,area_quadrilateral;
        if(choice!=Volume){ /*if user select volume ,this condition not allow this part.*/
        do{        
        printf("Please enter four sides of Quadrilateral :");
        a=check_num();
        if(a>0){ /*if the entered value is invalid,this condition is not allow get other value.*/
        b=check_num();
        if(b>0){
        c=check_num();          
        if(c>0){
        d=check_num(); 
          }
         }
        }
        
         if((a<=0)||(b<=0)||(c<=0)||(d<=0)){
         printf("!Error Pleas enter valid number. \n"); 
         }
              
         }while((a<=0)||(b<=0)||(c<=0)||(d<=0));
        }
         switch(choice){ /*whatever the calculator is wanted to calculate is sent to the function*/
          
         case Area:
        
         s=(a+b+c+d)/2.0;
         area_quadrilateral=((s-a)*(s-b)*(s-c)*(s-d));
         
         printf("Area of QUADRILATERAL : %f",sqrt(area_quadrilateral));        
         break;
        
         case Perimeter:
         
         printf("Perimeter of QUADRILATERAL : %f",(a+b+c+d));        
         break;

         case Volume:
        
         printf("!ERROR You cannot calculate the volume of Quadrilateral.Please try again.");        
         break;
         }
         printf("\n");
         printf("\n");
}

int calc_circle(int choice){

    float r;
    float area_circle,perimeter_circle;
    
        if(choice!=Volume){ /*if user select volume ,this condition not allow this part.*/
        do{        
        printf("Please enter the radius of Circle :");
        r=check_num();
     
         if(r<=0){
         printf("!Error Pleas enter valid number. \n"); 
         }
              
        }while(r<=0);
       }
         switch(choice){ /*whatever the calculator is wanted to calculate is sent to the function*/
          
         case Area:       
         area_circle=PI*r*r;
                 
         printf("Area of CIRCLE : %f",area_circle);        
         break;
        
         case Perimeter:
         perimeter_circle=2*PI*r;
         
         printf("Perimeter of CIRCLE : %f",perimeter_circle);        
         break;

         case Volume:
        
         printf("!ERROR You cannot calculate the volume of CIRCLE.Please try again.");        
         break;
         }
         printf("\n");
         printf("\n");
        
}
int calc_pyramid(int choice){

    float base_area,lateral_area,surface_area;
    float a,h,l,volume,lateral_side,perimeter_pyramid;
        
        if(choice==Area){/*if user select area,this part want to slant height.*/
        do{        
        printf("Please enter the base side and slant height of a Pyramid : ");
        a=check_num();
        if(a>0){ /*if the entered value is invalid,this condition is not allow get other value.*/
        l=check_num();
        }
         if((a<=0)||(l<=0)){
         printf("!Error Pleas enter valid number. \n"); 
         }
              
         }while((a<=0)||(l<=0));
        }
        
        else { /*if user does not select area,this part want to slant height.*/
        do{        
        printf("Please enter the base side and height of a Pyramid : ");
        a=check_num();
        if(a>0){ /*if the entered value is invalid,this condition is not allow get other value.*/
        h=check_num();
        }
         if((a<=0)||(h<=0)){
         printf("!Error Pleas enter valid number. \n"); 
         }
              
         }while((a<=0)||(h<=0));
        }
        
         switch(choice){ /*whatever the calculator is wanted to calculate is sent to the function*/
          
         case Area:
                
         base_area=a*a;
         
         lateral_area=2*a*l;
         
         surface_area=base_area+lateral_area;
                 
         printf("Base Surface Area of a PYRAMID : %f",base_area);
         printf("\n\n");
         printf("Lateral Surface Area of a PYRAMID : %f",lateral_area);
         printf("\n\n");
         printf("Surface Area of a PYRAMID : %f",surface_area);        
         break;
        
         case Perimeter:
         perimeter_pyramid=4*a;
         
         printf("Perimeter of PYRAMID : %f",perimeter_pyramid);        
         break;

         case Volume:
         volume=(1.0/3)*a*a*h;
         printf("Volume of a PYRAMID : %f",volume);               
         break;
         }
         printf("\n");
         printf("\n");
}
int calc_cylinder(int choice){
   
    float base_area,lateral_area,surface_area;
    float r,h,volume,perimeter_cylinder;
                
        do{        
        printf("Please enter the radius and height of a Cylinder : ");
        r=check_num();
        if(r>0){ /*if the entered value is invalid,this condition is not allow get other value.*/
        h=check_num();
        }
         if((r<=0)||(h<=0)){
         printf("!Error Pleas enter valid number. \n"); 
         }
              
        }while((r<=0)||(h<=0));
        
         switch(choice){ /*whatever the calculator is wanted to calculate is sent to the function*/
          
         case Area:
              
         base_area=PI*r*r;
         
         lateral_area=2*PI*r*h;
         
         surface_area=2*PI*r*(r+h);
                 
         printf("Base Surface Area of a CYLINDER : %f",base_area);
         printf("\n\n");
         printf("Lateral Surface Area of a CYLINDER : %f",lateral_area);
         printf("\n\n");
         printf("Surface Area of a CYLINDER : %f",surface_area);        
         break;
        
         case Perimeter:
         perimeter_cylinder=2*PI*r;
         
         printf("Perimeter of CYLINDER : %f",perimeter_cylinder);        
         break;

         case Volume:
         volume=PI*r*r*h;
         printf("Volume of a CYLINDER : %f",volume);               
         break;
         }
         printf("\n");
         printf("\n");
}
int check_num(){ /*this function check entered value is number or not.*/
    
    float intVal=0 ;
    char c='0';
    int convert;
    int check_int=1;
    int i=0,count=0;
    
    while(c != '\n') { /*takes value until this character is entered.*/
    c=getchar();
    if((c >= '0' && c <= '9')||((c=='.')&&(i!=0))) { /*If the entered character is a number, it enters this condition.*/
        if(c!='.'){ 
        convert = c - '0'; /*The entered character is converted to an integer value.*/
        intVal = intVal*10; /*Returns a multi-digit number entered as a character to its value.*/
        intVal =intVal + convert;/*Returns a multi-digit number entered as a character to its value.*/
         }
        else{  /*If a fractional number is entered, the count value increase.*/
        count++;} 
        }
        
    if(((c<'0')||(c>'9'))&& c!='\n' && c!='.'){/*If a character other than a digit is entered, it returns -1.*/
    check_int=-1;
     }
    if((c=='\n')&&(i==0)){ /*it throws an error if the first character is entered as the enter key.*/
    check_int=-1;
     }
    if((c=='.')&&(i==0)){/*if first character is dot,gives error.*/
     check_int=-1;
     } 
    i++;
    }
    if(count!=0){ /*If a fractional number is entered, the count value changes.*/
    intVal=intVal/(count*10);/*equates the fractional number to its original value.*/
    }
         
     if(check_int==1 ){
     return intVal;
     }
     else{
     return check_int;
     }    
}

