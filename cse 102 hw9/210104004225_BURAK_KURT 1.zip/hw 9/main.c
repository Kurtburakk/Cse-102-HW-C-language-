#include <stdio.h>
#include <stdlib.h>
#include <string.h>

union Person 
{
   char name[50];
   char address[50];
   int phone;
};
union Loan 
{
   float arr[3];
};
struct BankAccount
{
   union Person Customer;
   union Loan Loans[3];
};

void listCustomers(struct BankAccount *user,int *order_user);
void addCustomer (struct BankAccount *user,int *order_user);
void newLoan (struct BankAccount *user,int *order_user);
int calculateLoan(float amount, int period, float interestRate);
void getReport(int *order_user);

int main(){

   struct BankAccount *user = NULL; /*Memory alloceted for 50 customer.*/
   user = (struct BankAccount*)malloc(50 * sizeof(struct BankAccount));
   int a=0;
   int *order_user;/*this pointer hold to order of customer.*/
   order_user=&a;
   int choice=0;
   do {
      choice=0;
      printf("====================================================\n");
      printf("Welcome to the Bank Management System\n");
      printf("====================================================\n");
      printf("1. List All Customers \n");
      printf("2. Add New Customer \n");
      printf("3. New Loan Application \n");
      printf("4. Report Menu \n");
      printf("5. Exit System \n");
      scanf("%d",&choice);

      if(choice==1){
         listCustomers(user,order_user);
      }
      else if(choice==2){
         if(*order_user>49){ /*This condition does not allow to have more than 50 customers.*/
         printf("Maximum customer number of reached.\n");
         }
         else{
         addCustomer (user,order_user);
         }
      }
      else if(choice==3){
         newLoan(user,order_user);
      }
      else if(choice==4){
         getReport(order_user);
      }
   }while(choice!=5);/*this condition exit if user enter 5 number.*/

   return 0;
}
void listCustomers(struct BankAccount *user,int *order_user){

   int check_credit=0;
   float total_credit=0;
      
   for(int i=0;i<*order_user;i++){ /*The more customers there are, the more they return.*/
      printf("Customer ID = %d \n",(i+1));
      printf("Customer Name = %s \n",(user+i)->Customer.name); /*this part print the within person loan name*/
      check_credit=0; /*reset the value*/
      total_credit=0; /*reset the value*/
      for(int j=0;j<3;j++){ /*This number of turns can be up to three.*/
       if((user+i)->Loans[j].arr[0]!=0){ /*Checks if the customer has a loan in turn.*/
         total_credit=total_credit+((user+i)->Loans[j].arr[0]); /*If there is more than one credit, it finds the total result.*/
         if(check_credit==0){
         printf("Loans = [");
         printf("%.2f",(user+i)->Loans[j].arr[0]);
         }
         if(check_credit==1){
         printf("+ %.2f",(user+i)->Loans[j].arr[0]);
         }
         if(check_credit==2){
         printf("+ %.2f",(user+i)->Loans[j].arr[0]);
         }         
         check_credit++; /*As credit is found, the value increases and is printed accordingly.*/
       }
      }
      if(check_credit!=0){/*if founded customer's credit,this part print total credit.*/
         printf("] => %.2f\n",total_credit);
      }
      printf("\n");
      }
}
void addCustomer (struct BankAccount *user,int *order_user){
      FILE *file;
      char x;
      printf("%d-Customer: \n",(*order_user+1));/*this part print customer queue*/
      file=fopen("customer.txt","a");
      
      fprintf(file,"%d\n",(*order_user+1)); /*this part put customer queue in customer txt */

      printf("Please enter the customer's phone: ");
      scanf("%d",&(user+*order_user)->Customer.phone); /*this part get customer's phone in person union.*/
      x=getchar();
      fprintf(file,"%d\n",((user+*order_user)->Customer.phone));
      
      printf("Please enter the customer's address: ");
      scanf("%[^\n]",(user+*order_user)->Customer.address); /*this part get customer's address in person union.*/
      x=getchar();
      fprintf(file,"%s\n",((user+*order_user)->Customer.address)); /*this part put customer's address in customer txt.*/
      
      printf("Please enter the customer's name: ");
      scanf("%[^\n]",(user+*order_user)->Customer.name); /*this part get customer's name in person union.*/
      fprintf(file,"%s\n",((user+*order_user)->Customer.name)); /*this part put customer's name in customer txt.*/
      
      printf("\n");
      ++(*order_user); /*this part increase customer queue*/
      fclose(file);
}
void newLoan (struct BankAccount *user,int *order_user){
   int which_user;
   int which_credit=3;
   int check_credit;
   int total_loan;
   
   FILE *file1;
   file1=fopen("loan.txt","a");
   which_user=50;
   printf("Which customer(1,2,3,...) do you want to give credit to ? ");
   scanf("%d",&which_user);
   which_user=which_user-1;/*because first customer begin 0 number.*/
   
   
   if((which_user<*order_user)&&(which_user<50)){ /*this part check if entered customer queue smaller total customer number.*/
      check_credit=0;/*reset value*/
      which_credit=4;/*reset value*/
      while(check_credit<3){ /*this number of turns can be up to three.*/
       if((((user+which_user)->Loans[check_credit].arr[0])==0.0)&&(which_credit==4)){
         which_credit=check_credit; /*check credit change and this part only run once .And find free credit.*/
         printf("%d.credit:\n",(which_credit+1));
         printf("Enter the loan amount you want to withdraw? ");
         scanf("%f",&(user+which_user)->Loans[which_credit].arr[0]); /*this part hold to loan amount within union loans*/
         printf("How many periods will you take out a loan? ");
         scanf("%f",&(user+which_user)->Loans[which_credit].arr[1]); /*this part hold to period within union loans*/
         fprintf(file1,"%d\n",(which_user+1)); /*this part put customer queue and credit queue within loan.txt*/
         fprintf(file1,"%d\n",(which_credit+1));
         fprintf(file1,"%f\n",(user+which_user)->Loans[which_credit].arr[1]); /*this part put periods within loan.txt*/

         printf("Enter the interest rate of your loan? ");
         scanf("%f",&(user+which_user)->Loans[which_credit].arr[2]); /*this part hold to interest rate within union loans*/
         
         total_loan=calculateLoan((user+which_user)->Loans[which_credit].arr[0],(user+which_user)->Loans[which_credit].arr[1],
         (user+which_user)->Loans[which_credit].arr[2]); /*this part call the calculate loan function.*/
         (user+which_user)->Loans[which_credit].arr[0]=total_loan; /*total loan put the in amount loan place */
   
         fprintf(file1,"%f\n",(user+which_user)->Loans[which_credit].arr[0]); /*this part put total loan within loan.txt*/
       }
       check_credit++;
      }
   }
   else{
   printf("\nYou entered customer is not found.\n"); 
   }
   fclose(file1);
}
int calculateLoan(float amount, int period, float interestRate){
   int result;
   if(period==0){
      return amount;}
   else {
      return  (1+interestRate)*calculateLoan(amount,period-1,interestRate);}
}
void getReport(int *order_user){
   printf("%d\n",*order_user);
   FILE *file2;
   FILE *file3;
   int detail=0;
   printf("1=Customer Detail\n2=Loan Detail which:...\n");
   scanf("%d",&detail);
   printf("\n");
   if(detail==1){
      int a,b;
      char temp1[50];
      char temp2[50];
      file2=fopen("customer.txt","r");
      if(file2 == NULL){
      printf("File is not found.!\n");      
      }
      else{
      while(!feof(file2)){ /*this part read the file and get value*/
      fscanf(file2,"%d\n",&a);
      fscanf(file2,"%d\n",&b);
      fscanf(file2,"%[^\n]%*c",temp1);
      fscanf(file2,"%[^\n]%*c\n",temp2);
      printf("%d-Customer Phone: %d Address: %s Name: %s \n",a,b,temp1,temp2);
      }
      fclose(file2);
      }
   }
   else if(detail==2){
      int c,d;
      float x,y;
      int which_customer;
      int order_credit;
      float month_credit;
      int find_credit;

      printf("Which customer(1,2,3,...) do you want to see credit to ?");
      scanf("%d",&which_customer);
      if(which_customer<=*order_user){
        printf("Which loan(1,2,3) of the customer would you like to see?");
        scanf("%d",&order_credit);
        if(order_credit<4){
          find_credit=0;
          file3=fopen("loan.txt","r");
          if(file3 == NULL){
          printf("File is not found.!\n");      
          }
          else{
          while(!feof(file3)){
          fscanf(file3,"%d\n",&c); /*this part read loan.txt and get value*/
          fscanf(file3,"%d\n",&d);
          fscanf(file3,"%f\n",&x);
          fscanf(file3,"%f\n",&y);

          if(((c==which_customer)&&(d==order_credit))&&(find_credit==0)){
          find_credit=1; /*this part run only one because does not another value.*/
          month_credit=y/x;
          printf("Total Credit Value = %f\n",y); /* this part prints the loan divided by months */
            for(int i=1;i<=x;i++){
            printf("%d. Month Installment = %f\n",i,month_credit);
            }
           }
          }
          fclose(file3);
          }
         }
        else{
         printf("Credit has been not founded.\n");
       }
      }
      else{
         printf("Customer has been not founded.\n");
      }
   }
}
