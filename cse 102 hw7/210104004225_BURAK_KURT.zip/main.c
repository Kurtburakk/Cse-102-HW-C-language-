#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define MAX 100

void print_map(char grid_map[15][15]){ /*this function print the game area*/
int i,j;
for(i=0;i<15;i++){
       for(j=0;j<15;j++){
           printf("%c ",grid_map[i][j]);
       }
       printf("\n");
   }
}

int main(){
   srand(time(NULL));
    
   char grid_map[15][15];
   int i,j;

   for(i=0;i<15;i++){
       for(j=0;j<15;j++){
           grid_map[i][j]=' '; /*firstly each array elements equal to space character.*/
           /*this part will ensure that the selected words do not overlap*/
       }
   }

   int check_word[]={0,0,0,0,0,0,0}; /*this array provide each word is different the other word*/
   int hidden_start[7][3]; /*this array hold to starting points of words and which direction they will go */
   char hidden_word[7][MAX]; /* this array hold to seven words.*/
   FILE *file;

   /*check same rand number*/
   int check_same,l=0;
   int a,b=1;
   char temp_word[MAX];
   int w=0,k;
   do{

       do{
       check_same=0;
       a=rand()%50+1;
       for(k=0;k<7;k++){ /*random number checking same or not old random number*/
           if(k!=l) /*this part provide each word different is other words */
            {
                if(check_word[k]==a)check_same=1;
            }
           }
        }while(check_same==1);   
         check_word[l]=a; /*Hold to order of words*/
         l++;
   
    file=fopen("wordlist.txt","r");
    b=0;
    while(b<a){     /*finds the word in the desired order*/
    fscanf(file,"%s",temp_word);
    b++;
    }
    fclose(file);

    /*put the word to grid_map*/

int way,len,start_i,start_j;
int count_word=0; /*each word for times 1*/
    
    len=strlen(temp_word);
do {
    int check_place=0;
    int other_word=0;
    start_i=rand()%15;/* selecting random starting points*/
    start_j=rand()%15;/* selecting random starting points*/
    way=rand()%8+1;/* selecting random direction words*/
    switch(way){ /*the selected word is separated according to the direction it will go*/

        case 1:/*left upper cross way*/
        if((start_i-(len-1)>=0)&&(start_j-(len-1)>=0))check_place++;
        /*check are there sufficent area according length of word and starting points*/ 
        if(check_place==1){
           
           for(i=0;i<len;i++){ /*are there before place other word */
               if(grid_map[start_i-i][start_j-i]!=' ')other_word=1;
            }
            if(other_word==0){
            for(i=0;i<len;i++){
            grid_map[start_i-i][start_j-i]=temp_word[i];/*puts the word selected area */
            }
            count_word++;
            }
        }
        break;

        case 2:/*upper way*/
        if(start_i-(len-1)>=0)check_place++; /*check are there sufficent area according length of word and starting points*/
        if(check_place==1){
            for(i=0;i<len;i++){
               if(grid_map[start_i-i][start_j]!=' ')other_word=1;/*are there before place other word */
            }
            if(other_word==0){
           for(i=0;i<len;i++){
               grid_map[start_i-i][start_j]=temp_word[i];/*puts the word selected area */
             }
            count_word++;
            }
        }
        break;

         case 3: /*upper right cross way*/

        if((start_i-(len-1)>=0)&&(start_j+(len-1)<=14))check_place++; /*are there sufficient area*/
        if(check_place==1){
           
           for(i=0;i<len;i++){ 
               if(grid_map[start_i-i][start_j+i]!=' ')other_word=1; /*are there before place other word */
            }
            if(other_word==0){
            for(i=0;i<len;i++){
            grid_map[start_i-i][start_j+i]=temp_word[i]; /*puts the word selected area */
            }
            count_word++;
            }
        }
        break;

        case 4:  /*right way*/

        if(start_j+(len-1)<=14)check_place++; /*check are there sufficent area according length of word and starting points*/
        if(check_place==1){
            for(i=0;i<len;i++){
               if(grid_map[start_i][start_j+i]!=' ')other_word=1;/*are there before place other word */
            }
            if(other_word==0){
           for(i=0;i<len;i++){
               grid_map[start_i][start_j+i]=temp_word[i]; /*puts the word selected area */
             }
            count_word++;
            }
        }
        break;

        case 5: /*lower right cross way*/

        if((start_i+(len-1)<=14)&&(start_j+(len-1)<=14))check_place++;
        /*check are there sufficent area according length of word and starting points*/ 
        if(check_place==1){
           
           for(i=0;i<len;i++){ /*are there before place other word */
               if(grid_map[start_i+i][start_j+i]!=' ')other_word=1;
            }
            if(other_word==0){
            for(i=0;i<len;i++){
            grid_map[start_i+i][start_j+i]=temp_word[i];
            }
            count_word++;
            }
        }
        break;

        case 6:/*lower way*/

        if(start_i+(len-1)<=14)check_place++;
        if(check_place==1){
            for(i=0;i<len;i++){
               if(grid_map[start_i+i][start_j]!=' ')other_word=1;
            }
            if(other_word==0){
           for(i=0;i<len;i++){
               grid_map[start_i+i][start_j]=temp_word[i];
             }
            count_word++;
            }
        }
        break;

        case 7: /*lower left cross way*/

        if((start_i+(len-1)<=14)&&(start_j-(len-1)>=0))check_place++; /*are there sufficient area*/
        if(check_place==1){
           
           for(i=0;i<len;i++){ /*are there before place other word */
               if(grid_map[start_i+i][start_j-i]!=' ')other_word=1;
            }
            if(other_word==0){
            for(i=0;i<len;i++){
            grid_map[start_i+i][start_j-i]=temp_word[i];
            }
            count_word++;
            }
        }
        break;

        case 8:/*left way*/
        if(start_j-(len-1)>=0)check_place++;
        if(check_place==1){
            for(i=0;i<len;i++){
               if(grid_map[start_i][start_j-i]!=' ')other_word=1;
            }
            if(other_word==0){
           for(i=0;i<len;i++){
               grid_map[start_i][start_j-i]=temp_word[i];
             }
            count_word++;
            }
        }
        break;

    }
    /*put the word to grid_map*/

}while(count_word!=1); /*trying until the word is placed*/
    
    i=0;
    while(temp_word[i]!='\0'){
        hidden_word[w][i]=temp_word[i]; /*If word is placed, it is listed*/
        i++;
    }
    hidden_word[w][i]='\0';/* the last character is added*/
    hidden_start[w][0]=start_i;/*cordinate's start point*/
    hidden_start[w][1]=start_j;/*coordinate's start point*/
    hidden_start[w][2]=way; /*keep the direction of word*/
    
    /*this part given starting points and hidden words */
    printf("%d %d %s\n",hidden_start[w][0],hidden_start[w][1],hidden_word[w]); 
    w++; /*word number*/

   }while(w!=7);

   char c; /*anything character puts */
   for(i=0;i<15;i++){
       for(j=0;j<15;j++){
           if(grid_map[i][j]==' '){
              c=rand()%26+97;
              grid_map[i][j]=c;}    
           }
       }
      
   print_map(grid_map); /*first print map */

   int total_point=0,mistake=0,finding_word=0;
   int point_i,point_j,cor_word,find_way,check_quit=1;
   int len_enter,true_word,check_continue=1;
   char enter_word[MAX];
   char enter_first[MAX];
   do{
   printf("\nEnter coordinates and word:");
   scanf("%s",enter_first); /*the first character get the string*/
   if((enter_first[0]==':')&&(enter_first[1]=='q')){ /*if this condition become,quit game*/
       check_quit=0; 
   }
   else {
   if(((enter_first[0]>=48)&&(enter_first[0]<=57))&&((enter_first[1]>=48)&&(enter_first[1]<=57))){
       point_i=(enter_first[0]-48)*10; /*if the get number have two digit,this part convert to real value.*/
       point_i=point_i+(enter_first[1]-48);
   }
   else if((enter_first[0]>=48)&&(enter_first[0]<=57)){
       point_i=enter_first[0]-48; /*if the get number have one digit, this part convert to real value.*/
   }  
   scanf("%d ",&point_j); /*hold to second integer*/
   scanf("%s",enter_word);/*hold to word*/
   }
   check_continue=1;
   true_word=0;
   if(check_quit!=0){ /*if the user enter :q,do not enter this part*/

   for(i=0;i<7;i++){
       if((hidden_start[i][0]==point_i)&&(hidden_start[i][1]==point_j)){/*checking staring part*/
           cor_word=i; /*cor_word hold to order the word*/
           len_enter=strlen(enter_word);/*length of the entered word*/
           for(j=0;j<len_enter;j++){
               if((hidden_word[cor_word][j]==enter_word[j])&&(check_continue==1)){/*checking entered word*/
                   true_word=1;
               }
               else{ 
                true_word=0;
                check_continue=0;/*this value checking each element of array is true or not.*/
               }
           }
       }
   }   
   if(true_word==1){
       hidden_word[cor_word][0]='+';/*this part provide to not selected the same word.*/
       total_point=total_point+2;
       finding_word++; /*if this integer be seven numbers,game over. */
       printf("\nFounded! You got 2 points.Your total points : %d \n",total_point);

       /*put x */
       find_way=hidden_start[cor_word][2];/*We put a cross in that part according to the direction of the hidden word.*/
       switch(find_way){
           case 1:
           for(i=0;i<len_enter;i++){
            grid_map[point_i-i][point_j-i]='X';
            }
           break;

           case 2:
           for(i=0;i<len_enter;i++){
               grid_map[point_i-i][point_j]='X';
             }
           break;

           case 3:
           for(i=0;i<len_enter;i++){
               grid_map[point_i-i][point_j+i]='X';
             }
           break;

           case 4:
           for(i=0;i<len_enter;i++){
               grid_map[point_i][point_j+i]='X';
             }
           break;

           case 5:
           for(i=0;i<len_enter;i++){
               grid_map[point_i+i][point_j+i]='X';
             }
            break;
           
           case 6:
           for(i=0;i<len_enter;i++){
               grid_map[point_i+i][point_j]='X';
             }
            break;

            case 7:
           for(i=0;i<len_enter;i++){
               grid_map[point_i+i][point_j-i]='X';
             }
            break;

            case 8:
           for(i=0;i<len_enter;i++){
               grid_map[point_i][point_j-i]='X';
             }
            break;           
       }
   }
   if(true_word==0){
       mistake++;
       printf("\nYou did not find the word.You have %d healty.\n",(3-mistake));/*this part say your healty.*/
    }
   }
   if((mistake==3)||(finding_word==7)||(check_quit==0)){
       printf("\nEnd Game !!!\n");
   }
   else {
   print_map(grid_map);
   }

   }while((mistake!=3)&&(finding_word!=7)&&(check_quit!=0));/*this part check quit condition.*/
 
   if(total_point==14){
   printf("You win the game.");}

   printf("Your total point %d.",total_point);

   return 0;
}
