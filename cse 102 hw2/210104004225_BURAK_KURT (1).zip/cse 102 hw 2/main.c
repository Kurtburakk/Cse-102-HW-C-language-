#include <stdio.h>
#include <stdlib.h>
#include "util.h"


int main() {

    /* Ask for the problem selection (1,2,3) .....  */

    int problem;    
    
    printf("Which problem do you want to choose? ");
    scanf("%d",&problem);
    
    /* Get the input from the user for the first problem, i.e., to test dt1a and dt1b */
    /* Compare performances and print results */
    
    if(problem==1) { 
     float PL,PW,SL,SW;
     char kind_flower1,kind_flower2;
     
     printf("Enter the pedal length of the flower = ");
     scanf("%f",&PL);
     printf("Enter the pedal width of the flower = ");
     scanf("%f",&PW);
     printf("Enter the sepal length of the flower = ");
     scanf("%f",&SL);
     printf("Enter the sepal width of the flower = ");
     scanf("%f",&SW);
     
     kind_flower1 = dt1a(PL,PW,SL,SW); /*Our characters returned from functions will be kept in these variables.*/
     kind_flower2 = dt1b(PL,PW,SL,SW); /*Our characters returned from functions will be kept in these variables.*/
     
     if(kind_flower1==kind_flower2){  /* same decision situation*/
     
       if(kind_flower1=='s'){
       printf("Type of flower is Setosa.");}
       
       else if(kind_flower1=='v'){
       printf("Type of flower is Virginica.");}
             
       else {
       printf("Type of flower is Versicolor.");}
       printf("\n"); 
      }
     else{                                    /* different decision situation*/
     	  	/* first decision tree*/     	  	
       if(kind_flower1=='s'){  
       printf("According to the first decision,the type of flower is Setosa.");
        }
       else if(kind_flower1=='v'){
       printf("According to the first decision,the type of flower is Virginica.");
         }
       else {
       printf("According to the first decision,the type of flower is Versicolor.");
         }
       printf("\n");       
       		/* second decision tree*/       		
       if(kind_flower2=='s'){  
       printf("According to the second decision,the type of flower is Setosa.");
       }
       else if(kind_flower2=='v'){
       printf("According to the second decision,the type of flower is Virginica.");
       }      
       else {
       printf("According to the second decision,the type of flower is Versicolor.");
       }
       printf("\n");
      }
     }
     
     /* Get the input from the user for the second problem, i.e., to test dt2a and dt2b */
     /* Compare performances and print results */
     
     else if (problem==2){
     
     double x1,x2,x3,x4,x5;
     double result1,result2,distance;
     
     printf("Enter the value of x1 = ");
     scanf("%lf",&x1);
     printf("Enter the value of x2 = ");
     scanf("%lf",&x2);
     printf("Enter the value of x3 = ");
     scanf("%lf",&x3);
     do{
     printf("Enter the value of x4 must be 0 or 1 = ");
     scanf("%lf",&x4);
     }while( (x4!=0) && (x4!=1));
     do{
     printf("Enter the value of x5 must be 0 or 1  = ");
     scanf("%lf",&x5);
     }while( (x5!=0) && (x5!=1));
     
     result1=dt2a(x1,x2,x3,x4,x5);
     result2=dt2b(x1,x2,x3,x4,x5);
     
     distance=result1-result2;  /*If the difference is negative, we convert it to positive. */
     if(distance<0){
     distance=distance * -1; 
     }
     
      if(distance < CLOSE_ENOUGH){
      printf("The common result is = %lf ",(result1+result2)/2);
      }
      else
      {
      printf("According to the first decision,the result is = %lf",result1);
      printf("\n");
      printf("According to the second decision,the result is= %lf",result2);
      }
     }
    /* Get the input from the user for the third problem, i.e., to test dt3a and dt3b */
    /* Compare performances and print results */

    else if (problem==3){
    
    /*In this section, we show the user what the decision tree will represent and what the categorical numbers represent.*/ 
    printf("There are four common climate types in Turkey.");
    printf("\n");
    printf("These are the Black Sea climate (Eastern black sea,Western black sea),");
    printf("\n");
    printf("the Mediterranean climate and the continental climate(Southeast Anatolian,");
    printf("\n");
    printf("Central Anatolian and Eastern Anatolian continental climate).");
    printf("\n"); 
    printf("We will decide which climate type your region is suitable for after we get the values ");
    printf("\n"); 
    printf("such as the rainy season,the coldest month,thorny type of trees,the annual average temperature,");
    printf("\n");
    printf("the annual temperature difference and the amount of moisture from you.");    
    printf("\n");
    printf("////// SEASONS =  Winter=1  Autumn=2 Summer=3 Spring=4  //////");
    printf("\n");
    printf("////// MONTHS = January=1  February=2  March=3 April=4 May=5 June=6 ");
    printf("July=7 August=8 September=9 October=10 November=11 December=12 //////");
    printf("\n");
    
    double av_temperature,dif_temperature,moisture;
    int rain_season,coldest_month,thorny_trees;
    
    do{
    printf("Enter which season it rains the most?  = ");
    scanf("%d",&rain_season);
    }while((rain_season<1) || (rain_season>4)); /*This part prevents entering values other than categorical numbers */
    
    do{
    printf("Enter which is the coldest month  = ");
    scanf("%d",&coldest_month);
    }while((coldest_month<1) || (coldest_month>12)); /*This part prevents entering values other than categorical numbers */
    
    do{    
    printf("Are the leaves of the trees in the area thorny? (yes=1 no=0) = ");
    scanf("%d",&thorny_trees);
    }while( (thorny_trees!=0) && (thorny_trees!=1)); /*This part prevents entering values other 0 or 1 numbers */
    
    printf("Enter the annual average temperature = ");
    scanf("%lf",&av_temperature);
    printf("Enter annual temperature difference = ");
    scanf("%lf",&dif_temperature);
    printf("Enter enter the amount of moisture  = ");
    scanf("%lf",&moisture);
       
    dt3a(rain_season,coldest_month,thorny_trees,av_temperature,dif_temperature,moisture);
    dt3b(rain_season,coldest_month,thorny_trees,av_temperature,dif_temperature,moisture);    
    
    }
    else {
    printf("You can choose numbers 1,2 or 3 ."); 
    /*If the user does not select one of the 1,2 or 3 problems,it gives an error. */
    }   
    return 0;
}
