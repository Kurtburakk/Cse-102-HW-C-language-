#ifndef _UTIL_H_
#define _UTIL_H_

#define CLOSE_ENOUGH 0.001

/* Example decision tree - see the HW2 description 
int dt0(int t, double p, double h, char s, int w);*/

char dt1a(float PL,float PW,float SL,float SW);
char dt1b(float PL,float PW,float SL,float SW);

double dt2a(double x1,double x2,double x3,double x4,double x5);
double dt2b(double x1,double x2,double x3,double x4,double x5);

/* Write the prototype of the functions implementing the decision trees for the third problem */

void dt3a(int rain_season,int coldest_month,int thorny_trees,double av_temperature,double dif_temperature,double moisture);
void dt3b(int rain_season,int coldest_month,int thorny_trees,double av_temperature,double dif_temperature,double moisture);

#endif /* _UTIL_H_ */
