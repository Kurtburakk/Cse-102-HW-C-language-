#include <stdio.h>
#include <math.h>
#include "util.h"

/* Example decision tree - see the HW2 description 
int dt0(int t, double p, double h, int s, int w) {
    int r = 0;
    if (t>35 && w!=3) r = 1;
    else if (t<=35 && s==0) r = 1;
    return r;
} */

/* Provide your implementations for all the requested functions here */


char dt1a(float PL,float PW,float SL,float SW){ /* s = setose  v = virginica c = versicolor */

  /*   char kind_flower='s' */
     if(PL<2.45){    /* one step */
     return 's';
    }
     else {          /* one step */
     
      if(PW<1.75){   /* two step */
      
        if(PL<4.95){  /* three step */
       
         if(PW<1.65) { /* four step */ 
         return 'c';
        }
         else {        /* four step */
         return 'v';}
       }
        else{         /* three step */
        return 'v';}
       }
        
      else {        /* two step */
      return 'v';} 
    } 
}
char dt1b(float PL,float PW,float SL,float SW){ /* s = setose  v = virginica c = versicolor */

     if(PL<2.55){              	/* one step */
     return 's';
     }          
     else { 		       	/* one step */
     
      if(PW<1.69){	       	/* two step */
            
        if(PL<4.85){		/* three step */
        return 'c';}       
        else {			/* three step */
        return 'v';}         
       }
      else {			/* two step */
       return 'v';
       }
     }
}
double dt2a(double x1,double x2,double x3,double x4,double x5){

    if(x1<31.5)
    {          		  /* one step */
     if(x2>-2.5){	  /* two step */
      return 5.0;}
     else
     {               	  /* two step */
      if( ((x2-0.1)<=x1) && (x1<=(x2+0.1)) ){ /* three step */
      return 2.1;}      
      else{               /* three step */
      return -1.1;}
     }
    }
    else 
    {                           /* one step */
     if( (-1<=x3) && (x3<=2)){  /* two step */
     return 1.4;}  
     else
     {			        /* two step */
      if((x4 && x5)==1){	/* three step */
      return -2.23;}		
      else{			/* three step */
      return 11.0;}
     }     
    }
}
double dt2b(double x1,double x2,double x3,double x4,double x5){
    
     if((12<x1) && (x1<22))
     {  			/* one step */
      if(x3>5/3){	      /* two step */
      return -2.0;}             
      else
      {		      				  /* two step */
      if(((x1<-0.1)<=x3) && (x3<=(x1+0.1))){      /* three step */
      return 1.01;}
      else{                                      /* three step */
      return -8;}
      }
     }
     else
     { 		     /* one step */    
      if((x4 && x5)==1){
      return -1;}     
      else
      {
       if((-1<=x2) && (x2<=2)){
       return (-1.0/7.0);}
       else{
       return (sqrt(2)/3);}
      }
     }
}
void dt3a(int rain_season,int coldest_month,int thorny_trees,double av_temperature,double dif_temperature,double moisture){

     printf("According to the first decision : ");
      
     if(rain_season<3) /*The desicion tree is divided into two according to the seasons of precipitation. */
     {
      if(thorny_trees==1)
    /*If there are thorns on the trees, it is the Black Sea climate, otherwise it is the Mediterranean climate.  */
      {
       if(dif_temperature<5)
       { /*In the Black Sea climate, it is separated according to the temperature difference. */
       printf("The eastern black sea climate is effective in your region. ");
       }
       else
       {
       printf("The western black sea climate is effective in your region. ");
       } 
      }
      else
      {
      printf("Mediterranean climate is effective in your region.");
      }
     }   
     else
     {
      if(moisture<70)
       { 
   /*According to the moisture rate, it is understood whether it is a Marmara climate or a continental climate. */
        if(coldest_month<=3)
        {
    /*According to which month it is cold, southeast continental climate and other continental climates are separated. */
         if(av_temperature<6)
         {
    /*According to the average temperature, central and eastern continental climates are separated. */
          printf("Eastern Anatolian continental climate is effective in your region. ");
         }
         else
         {
          printf("Central Anatolian continental climate is effective in your region.");
         }
        }
        else
        {
         printf("Southeast Anatolian continental climate is effective in your region.");
        }
       }
      else
       { 
        printf("Marmara climate is effective in your region.");
       }
     }
     printf("\n");    
}
void dt3b(int rain_season,int coldest_month,int thorny_trees,double av_temperature,double dif_temperature,double moisture){

     printf("According to the second decision : ");

     if(rain_season<3) /*The tree is divided into two according to the seasons of precipitation. */
     {
      if(thorny_trees==1)
      {
       /*If there are thorns on the trees, it is the Black Sea climate, otherwise it is the Mediterranean climate.  */
       if(av_temperature<=8)
       {
       /*According to the average temperature, western and eastern black sea climates are separated. */
       printf("The eastern black sea climate is effective in your region. ");
       }
       else
       {
       printf("The western black sea climate is effective in your region. ");
       } 
      }
      else
      {
      printf("Mediterranean climate is effective in your region.");
      }
     }   
     else
     {
      if(moisture<60.5)
       {
   /*According to the moisture rate, it is understood whether it is a Marmara climate or a continental climate. */
        if(coldest_month<=4)
        { 
   /*It is divided into southeast continental climate or other continental climates according to the coldest month. */
         if(dif_temperature<=15)
         {  
   /*According to the average temperature, eastern and central continental climates are separated. */   
          printf("Eastern Anatolian continental climate is effective in your region. ");
         }
         else
         {
          printf("Central Anatolian continental climate is effective in your region.");
         }
        }
        else
        {
         printf("Southeast Anatolian continental climate is effective in your region.");
        }
       }
      else
       {
        printf("Marmara climate is effective in your region.");
       }
     }
}
