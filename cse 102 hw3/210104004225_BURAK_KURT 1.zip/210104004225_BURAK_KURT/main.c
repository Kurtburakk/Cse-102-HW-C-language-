#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int sum(int n1,int n2,int flag);
int multi(int n1,int n2,int flag);
int isprime(int a);
void print_file();
void write_file (int number);
void sort_file ();

int main() {
  
    while(1){

    int operation;
    printf("Select operation");
    printf("\n");
    printf("1. Calculate sum/multiplication between two numbers");
    printf("\n");
    printf("2. Calculate prime numbers");
    printf("\n");
    printf("3. Show number sequence in file");
    printf("\n");
    printf("4. Sort number sequence in file");
    printf("\n");
    printf("--------------------------------");
    printf("\n");
    scanf("%d",&operation);
    
  
    if(operation==1){				/* PART 1 */
    				
    int operation_flag,flag;
    int n1,n2,result;
    						
    printf("Select operation");
    printf("\n");
    printf("Please enter '0' for sum,'1' for multiplication.");
    scanf("%d",&operation_flag);
    
    switch(operation_flag)
    {
        case 0:
        printf("Please enter '0' to work on even numbers,'1' to work on odd numbers.");
    	scanf("%d",&flag);
    	
    	switch(flag){
    	 case 0:
    	 printf("Please enter two different number:");
    	 printf("\n");
    	 printf("Number 1: ");
    	 scanf("%d",&n1);
    	 printf("Number 2: ");
    	 scanf("%d",&n2);
    	 if(n1==n2){
    	 printf("Two values should not be the same.");
    	 }
    	 else if((n1<0)||(n2<0)){
    	 printf("n1 or n2 values should not be the negative.");
    	 }
    	 else{    	 
    	 result=sum(n1,n2,flag);
    	 write_file(result);    
         printf("The result is written to the result.txt file.");
         printf("\n");}
    	 break;
    	 
    	 case 1:
    	 printf("Please enter two different number:");
    	 printf("\n");
    	 printf("Number 1: ");
    	 scanf("%d",&n1);
    	 printf("Number 2: ");
    	 scanf("%d",&n2);
    	 if(n1==n2){
    	 printf("Two values should not be the same.");
    	 }
    	 else if((n1<0)||(n2<0)){
    	 printf("n1 or n2 values should not be the negative.");
    	 }    	 
    	 else{
    	 result=sum(n1,n2,flag);
    	 write_file(result);    
         printf("The result is written to the result.txt file.");
         printf("\n");}
    	 default :
    	 printf("You entered a invalid flag number.");
    	 } 
        break;

       case 1:
       printf("Please enter '0' to work on even numbers,'1' to work on odd numbers.");
       scanf("%d",&flag);
    	
    	switch(flag){
    	 case 0:
    	 printf("Please enter two different number:");
    	 printf("\n");
    	 printf("Number 1: ");
    	 scanf("%d",&n1);
    	 printf("Number 2: ");
    	 scanf("%d",&n2);
    	 if(n1==n2){
    	 printf("Two values should not be the same.");
    	 }
    	 else if((n1<0)||(n2<0)){
    	 printf("n1 or n2 values should not be the negative.");
    	 }   	 
    	 else{result=multi(n1,n2,flag);
    	 write_file(result);    
         printf("The result is written to the result.txt file.");
         printf("\n");}
    	 break;
    	 case 1:
    	 printf("Please enter two different number:");
    	 printf("\n");
    	 printf("Number 1: ");
    	 scanf("%d",&n1);
    	 printf("Number 2: ");
    	 scanf("%d",&n2);
    	 if(n1==n2){
    	 printf("Two values should not be the same.");
    	 }
    	 else if((n1<0)||(n2<0)){
    	 printf("n1 or n2 values should not be the negative.");
    	 }  	 
    	 else{
    	 result=multi(n1,n2,flag);
    	 write_file(result);   
         printf("The result is written to the result.txt file.");
         printf("\n");}
    	 break;
    	 default :
    	 printf("You entered a invalid flag number."); 
    	 }
       default:
       printf("You entered a invalid flag number.");    
    }
   } 
    					/* PART 2*/
    else if(operation==2){
    int n,result_2,A;
    					
    printf("Please enter an integer: ");
    scanf("%d",&n);
    
    for(A=2;A<n;A++){
    
    result_2=isprime(A);
    
     if(result_2!=1){ /*A return value other than 1 is the smallest divisor. */
     printf("%d is not a prime number, it is dividible by %d.",A,result_2);
     printf("\n");
     }
     else{  /*If it returns 1, the number is prime. */
     printf("%d is a prime number.",A);
     printf("\n");
     } 
    } 
   }                                      /* PART 3 */
   else if(operation==3){
   
   printf("Result:");
   printf("\n");
   print_file();
   }
   else if(operation==4){
   printf("Sorting is complete.");
   printf("Result: ");
   sort_file();  
   }
   else {
   printf("You entered invaild operation number.");
   }
    return 0;
    }
}

					/* FUNCTIONS */
int sum(int n1,int n2,int flag){

int temp,i;
int result=0;
int one_step=0;

    printf("Result");
    printf("\n");
    
    if(n1>n2){ /*fixes the number order */
    temp=n1;
    n1=n2;
    n2=temp;
    }
    
    /* even numbers */
    if(flag==0){ 
  
    for(i=n1+1;i<n2;i++){
    
     if(i%2==0){
     result = result +i;
       
       if(one_step==0){ /* It prevents the last part from being +=. */
       printf("%d",i);
       one_step=1;}
       else{
       printf(" + %d",i);}     
      }
     }
    printf(" = %d",result);   
    }
    /* odd numbers */
        
    if(flag==1){  
      
    for(i=n1+1;i<n2;i++){
    
    if(i%2==1){
     result = result +i;
       
       if(one_step==0){ /* It prevents the last part from being +=. */
       printf("%d",i);
       one_step=1;}
       else{
       printf(" + %d",i);}     
      }
     }
    printf(" = %d",result);   
    }
    printf("\n");

    return result;
}
int multi(int n1,int n2,int flag){

int temp,i;
int result=1;
int one_step=0;

    printf("Result");
    printf("\n");
    
    if(n1>n2){  /*fixes the number order */
    temp=n1;
    n1=n2;
    n2=temp;
    }
        
    /* even numbers */
    if(flag==0){ 
  
    for(i=n1+1;i<n2;i++){
    
     if(i%2==0){
     result = result * i;
       
       if(one_step==0){ /* It prevents the last part from being *=. */
       printf("%d",i);
       one_step=1;}
       else{
       printf(" * %d",i);}     
      }
     }
     if(result<0){
    result= result * -1;}      
    return result;

    printf(" = %d",result);   
    }

    /* odd numbers */
        
    if(flag==1){  
      
    for(i=n1+1;i<n2;i++){
    
    if(i%2==1){
     result = result * i;
       
       if(one_step==0){ /* It prevents the last part from being *=. */
       printf("%d",i);
       one_step=1;}
       else{
       printf(" * %d",i);}     
      }
     }
    printf(" = %d",result);   
    }
    if(result<0){
    result= result * -1;}      
    return result;
}
int isprime(int a){

int i,j;
int A,divisor;
int is_prime;
int first_divisor;
   
    A=sqrt(a);
    divisor=0;
    is_prime=1;
    
    for(i=2;i<=A;i++){
      
      if((a%i==0) && (divisor==0)){
      first_divisor=i;
      divisor=1;       
      is_prime=0;
      }      
     }     
     if(is_prime==0){ /*If there is any divisor this number will change and it will be understood that it is not prime.*/
     return first_divisor;}
     else{
     return 1;}
}
void print_file(){

    int value;
    FILE *file;    
    file=fopen("result.txt","r");
    while(!feof(file)){
    fscanf(file,"%d ",&value);
    printf("%d ",value);
    }
    fclose(file);
}
void write_file (int number){
    
    FILE *file;
    file=fopen("result.txt","a");
    fprintf(file,"%d ",number);
    fclose(file);
}
void sort_file (){ /*///////////////////////////////////////////////////////////////////////////*/
     
    int value;
    int min_1,min_2,min_3=0;
    int first_value;
    int max_value,i=0,j=0;
    int temp1=0,temp2=0,temp3=0;
    int check=0;

    /*We find the first value */
    FILE *file;
    file=fopen("result.txt","r");
    fscanf(file,"%d ",&first_value);
    max_value=first_value;   
    fclose(file);
    
    /* We find the greatest value */
    file=fopen("result.txt","r"); 
    while(!feof(file)){
    fscanf(file,"%d ",&value);
    if(value>max_value){  
    max_value=value;
     }
    }
    fclose(file); 
    
    file=fopen("result.txt","r"); /*We find how many elements are in our file. */
    while(!feof(file)){
    fscanf(file,"%d ",&value);
    i++;}
    fclose(file);

    while(i>j) {  /*Prevents us from printing an unnecessary number of elements.*/
    
    min_1=min_2=min_3=max_value; /*It allows us to get new numbers and find the smallest values. */
    
    
    file=fopen("result.txt","r");
    while(!feof(file)){
    fscanf(file,"%d ",&value);
    
    if(value>check){  /*We get rid of the previous minimum values.*/
    
     if (value<min_1){  /*the part that finds the minimum values*/ 
      min_3 = min_2;
      min_2 = min_1;
      min_1 = value;}
     else if (value<min_2){
      min_3 = min_2;
      min_2 = value;}
     else if (value<min_3){
      min_3 = value;}
     }
    }
    fclose(file);
    
    FILE *file2;
    file2=fopen("temporary.txt","a");
    if(i!=j){ /*Prevents us from printing an unnecessary number of elements.*/
    if(min_1>=temp1){
    fprintf(file2,"%d ",min_1);
    j++;} /*It will increase with each printed number and prevent the case of pressing more than the number of elements.*/
    }
    if(i!=j){
    if(min_2>=temp2){
    fprintf(file2,"%d ",min_2);
    j++;} /*It will increase with each printed number and prevent the case of pressing more than the number of elements.*/
    }
    if(i!=j){
    if(min_3>=temp3){
    fprintf(file2,"%d ",min_3);
    j++;} /*It will increase with each printed number and prevent the case of pressing more than the number of elements.*/
    }
    fclose(file2);    
      
     temp1=min_1;
     temp2=min_2;
     temp3=min_3;
     check=min_3; /*We get rid of the previous minimum values.*/
   }
   
   int trans,counter=0;
   int check_3=0;
   int a=0;
    
   FILE *file2;
   file=fopen("result.txt","w"); /*We will overwrite the result file with the w command.*/
    
   while(i>a){  /*Prevents us from printing an unnecessary number of elements.*/
   file2=fopen("temporary.txt","r");
   counter=0;  
   while(!feof(file2)){
   
   fscanf(file2,"%d ",&trans);
   if((trans>check_3) && (counter==0)){  /*It allows us to get the elements in order. */
   check_3=trans;  
   counter=1;
    }
   }
   fclose(file2);          
   fprintf(file,"%d ",check_3);  /*We will overwrite the result file*/ 
   a++;
   } 
   fclose(file);    
   print_file(); /*Prints the final result.txt file. */
   
}
    
